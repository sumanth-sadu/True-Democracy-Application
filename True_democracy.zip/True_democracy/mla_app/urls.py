from django.conf.urls import url
from mla_app import views
from django.urls import path
from django.contrib.auth import views as auth_views
from django.contrib import admin
app_name = 'mla'

urlpatterns = [
	#path('forms/',views.form_name,name="forms"),
	path('<str:cname>/',views.speci_mla,name='register'),
	path('',views.speci_mla,name='register'),
	
	path('api/data/',views.grpah,name='api-data'),
	path('<str:cname>/api/data/',views.grpah,name='api-data'),

	path('api/data/1',views.grpah_1,name='apdata'),
	path('<str:cname>/api/data/1',views.grpah_1,name='apdata'),

	path('api/data/2',views.grpah_2,name='apdata'),
	path('<str:cname>/api/data/2',views.grpah_2,name='apdata'),

	path('api/data/3',views.grpah_3,name='apdata'),
	path('<str:cname>/api/data/3',views.grpah_3,name='apdata'),

	path('api/data/4',views.grpah_4,name='ap_newdata'),
	path('<str:cname>/api/data/4',views.grpah_4,name='ap_newdata'),

		path('api/data/5',views.grpah_5,name='apnewdata'),
	path('<str:cname>/api/data/5',views.grpah_5,name='apnewdata'),

] 
