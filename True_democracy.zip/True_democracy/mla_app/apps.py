from django.apps import AppConfig


class MlaAppConfig(AppConfig):
    name = 'mla_app'
