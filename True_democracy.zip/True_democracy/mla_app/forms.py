from django import forms
from mla_app.models import Complaints,MLA_posts
from django.core import validators

# below function is for custom validation which can be applied to any field

# def check_for_z(value):
#     if value[0].lower() != 'z':
#         raise forms.ValidationError('name needs to start with z')

class tweetForms(forms.ModelForm):
    content = forms.CharField(required=True,widget=forms.Textarea)
    class Meta:
        model = MLA_posts
        fields = ('content',)

class formnew(forms.Form):
    pro = forms.ChoiceField(choices=[('water','Water'),('electricity','Electricity'),('corruption','Corruption'),('education','Education'),('safety','Safety'),('disease','Diseases'),('cleanliness','Cleanliness'),('airpollution','Air Pollution'),('noisepollution','Noise Pollution'),('bank','Bank'),('other','Other')])
    temp=forms.ChoiceField(choices=[('Complaint', 'complaint'),('Request', 'request')])

class FormName(forms.ModelForm):
    longitude = forms.CharField(widget=forms.HiddenInput,required=False)
    constituency = forms.CharField(widget=forms.HiddenInput,required=False)
    type_com=forms.ChoiceField(choices=[('Complaint', 'complaint'),('Request', 'request')],required=True)
    problem = forms.ChoiceField(choices=[('water','Water'),('electricity','Electricity'),('corruption','Corruption'),('education','Education'),('safety','Safety'),('disease','Diseases'),('cleanliness','Cleanliness'),('airpollution','Air Pollution'),('noisepollution','Noise Pollution'),('bank','Bank'),('other','Other')])
    details = forms.CharField(widget=forms.Textarea,validators = [validators.MaxLengthValidator(100)],label="Describe accurately the details of your complaint and against whom:",required=True)
    describe = forms.CharField(widget=forms.Textarea,validators = [validators.MaxLengthValidator(100)],label="Describe how the incident you are complaining about has impacted negatively on your life:",required=True)
    government = forms.CharField(widget=forms.Textarea,label="Describe how the government can deal effectively with your complaint:",required=False)
    comments = forms.CharField(widget=forms.Textarea,label="Give additional comments which you believe will be important during further investigations of your complaint:",required=False)
    botcatcher = forms.CharField(required=False,
                                widget=forms.HiddenInput,
                                validators = [validators.MaxLengthValidator(0)])

    class Meta:
        model = Complaints
        fields = '__all__'

class Clear(forms.Form):
    start_date = forms.DateField(label='Start Date : ', widget=forms.SelectDateWidget)
    end_date= forms.DateField(label='End Date : ', widget=forms.SelectDateWidget)
    type_com=forms.ChoiceField(choices=[('Complaint', 'complaint'),('Request', 'request')],required=True)
    problem = forms.ChoiceField(choices=[('water','Water'),('electricity','Electricity'),('corruption','Corruption'),('education','Education'),('safety','Safety'),('disease','Diseases'),('cleanliness','Cleanliness'),('airpollution','Air Pollution'),('noisepollution','Noise Pollution'),('bank','Bank'),('other','Other')])
#below is a customised method to catch botcatchers

    # def clean_botcatcher(self):
    #     botcatcher = self.cleaned_data['botcatcher']
    #     if len(botcatcher) > 0:
    #         raise forms.ValidationError('error due to botcatcher')
    #     return botcatcher

