from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from django.urls import reverse
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from sign_up import forms
from sign_up.forms import UserForm,UserProfileInfoForm
from sign_up.models import Info,UserProfileInfo
from django.core.files.storage import FileSystemStorage
from django.conf import settings
from django.contrib import messages
import urllib,json,requests
from sign_up.models import Info,UserProfileInfo,Validate_otp
from random import randrange
# Create your views here.
def base(request):
	return render(request,'base.html',{})

def data(request):
	webpages_list = Info.objects.all()
	my_dict = {'List':webpages_list}
	return render(request,'page.html',context = my_dict)

def gen_otp(uid,phn):
	otp = randrange(111111,999999)
	url = "http://2factor.in/API/V1/89d3d805-c971-11ea-9fa5-0200cd936042/SMS/" + str(phn) +"/"+str(otp)+"/OTPSEND"
	resp = requests.get(url)
	print(resp.json())
	if resp.json().get('Status') == "Success":
		Validate_otp(otp=otp,uid=uid).save()

def register(request):
	registered = False
	if request.method == "POST":
		user_form = UserForm(data = request.POST)
		profile_form = UserProfileInfoForm(data = request.POST)

		if user_form.is_valid() and profile_form.is_valid():
			recaptcha_response = request.POST.get('g-recaptcha-response')
			url = 'https://www.google.com/recaptcha/api/siteverify'
			values = {
			'secret' : settings.GOOGLE_RECAPTCHA_SECRET_KEY,
			'response' : recaptcha_response,
			}
			data = urllib.parse.urlencode(values).encode()
			req = urllib.request.Request(url,data=data)
			response = urllib.request.urlopen(req)
			result = json.loads(response.read().decode())
			user = user_form.save()
			user.set_password(user.password)
			profile = profile_form.save(commit = False)
			profile.user = user
			if result['success']:
				user.save()
				profile.save()
				uid = profile.Aadhar_id
				phn = profile.PhNo2
				gt=gen_otp(uid,phn)
				return render(request,'sign_up/enter_otp.html',{'uid':uid})
			else:
				messege.error(request,'invalid reCAPTHA')
		else:
			return render(request,'sign_up/signup.html',{'user_form_errors':user_form.non_field_errors,'profile_form_errors':profile_form.non_field_errors})
	else:
		user_form = UserForm()
		profile_form = UserProfileInfoForm()
	return render(request,'sign_up/signup.html',{'user_form':user_form,'profile_form':profile_form,'registered':registered})


@login_required
def user_logout(request):
	logout(request)
	return HttpResponseRedirect(reverse('index'))

@login_required
def special(request):
	return HttpResponse("You are Logged in")

def user_login(request):
	if request.method == 'POST':
		username = request.POST.get('username')
		password = request.POST.get('password')

		user = authenticate(username=username,password=password)

		if user:
			if user.is_active:
				login(request,user)
				return HttpResponseRedirect(reverse('index'))

			else:
				return HttpResponse("Inactive")
		else:
			return render(request,'sign_up/invalid.html',{})
	else:
		return render(request,'sign_up/login.html',{})

def home(request):
	x=len(UserProfileInfo.objects.all())
	return render(request,'home.html',{"number_of_users":x})

@login_required
def profile(request):
	 return render(request,'profile.html')

# Profil Page
def edit(request):
	if request.method == 'POST':
		model = UserProfileInfo.objects.get(user = request.user)
		model.Name = request.POST.get('name')
		model.profile_pic = request.POST.get('pro')
		model.save()
	return render(request,'profile.html')

@login_required
def profile(request):
	model = UserProfileInfo.objects.get(user = request.user)
	anumber = model.Aadhar_id
	num = anumber[0]+"*"*(len(anumber)-3)+ anumber[-2]+ anumber[-1]
	return render(request,'profile.html',{'model':model,'num':num})

#OTP
def otp_validation(request):
	validated = False
	registered = False
	invalid = False
	if request.method == "POST":
		otp = request.POST["otp"]
		uid = request.POST["uid"]
		try:
			obj = Validate_otp.objects.get(otp=otp,uid=uid)
			uobj = UserProfileInfo.objects.get(Aadhar_id=uid)
			uobj.phn_valid = 1
			uobj.save()
			obj.delete()
			validated = True
			registered=True
			return render(request,'sign_up/signup.html',{'registered':registered,'validated':validated})
		except:
			invalid = True
			obj = Validate_otp.objects.get(uid=uid)
			obj.delete()
			obj1=UserProfileInfo.objects.get(Aadhar_id=uid)
			phn = obj1.PhNo2
			gt=gen_otp(uid,phn)
			return render(request,'sign_up/enter_otp.html',{'uid':uid,'invalid':invalid})