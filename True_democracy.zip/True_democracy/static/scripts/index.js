/*Downloaded from https://www.codeseek.co/suez/loginregistration-form-transition-RpNXOR */
document.querySelector('.img__btn').addEventListener('click', function() {
  document.querySelector('.cont').classList.toggle('s--signup');
});